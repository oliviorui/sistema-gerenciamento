<?php
require_once '../../config/bootstrap.php';
require_admin($conn);
