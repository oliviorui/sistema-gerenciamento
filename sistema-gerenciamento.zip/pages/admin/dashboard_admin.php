<?php
require_once 'protecao_admin.php';
$nome = (string)($_SESSION['usuario_nome'] ?? 'Admin');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Painel Admin</title>
  <link rel="stylesheet" href="../../css/app.css">
</head>
<body>
<div class="app">
  <aside class="sidebar">
    <div class="brand">
      <img src="../../img/logo.png" alt="Logo">
      <strong>Sistema Acadêmico</strong>
    </div>
    <nav class="nav">
      <a class="active" href="dashboard_admin.php">Dashboard</a>
      <a href="usuarios.php">Utilizadores</a>
      <a href="turmas.php">Turmas</a>
      <a href="disciplinas.php">Disciplinas</a>
      <a href="atribuicoes.php">Atribuições</a>
      <a href="logs.php">Logs</a>
      <a href="../../controllers/logout.php">Sair</a>
    </nav>
  </aside>

  <main class="content">
    <h1>Bem-vindo, <?= htmlspecialchars($nome) ?></h1>
    <p>Escolha um módulo no menu para gerenciar o sistema.</p>
  </main>
</div>
</body>
</html>
